

<?php $__env->startSection('custom-header'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/c3/c3.min.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/dropify/css/dropify.min.css')); ?>">


    <style>
        .card .body, .card .card-body {
            padding: 18px!important;
        }
        @media  all and (max-height: 1000px){
            div.dataTables_wrapper div.dataTables_filter{
                margin-top: -35px!important;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
   Search User
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('block-header'); ?>
    <div class="block-header">

        <div class="row clearfix">
            <div class="col-md-6 col-sm-12">
                <h1>Seach user</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Lubricant</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Seach user</li>
                    </ol>
                </nav>
            </div>            
            
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="row clearfix">
        <div class="col-12">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <i class="fa fa-check-circle"></i> User created Sucessfully
                </div>
            <?php endif; ?>
            
            <?php if(session('delete')): ?>
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <i class="fa fa-check-circle"></i> User Deleted Sucessfully
                </div>
            <?php endif; ?> 
            <div class="card">                    
                <div class="tab-content">

                    <div class="" id="">
                        <div class="body mb-3">
                            <div class="row">
                                <div class="col-3">
                                    <div class="text-left">
                                        <button type="button" class="btn btn-sm mb-1 btn-outline-primary" data-toggle="modal" data-target="#exampleModal">Select Address</button>
                                    </div>
                                </div>
                                <div class="col-9">
                                    <div class="text-right">
                                        <button type="button" class="btn btn-sm mb-1 btn-filter btn-outline-secondary" data-target="all">All</button>
                                        <button type="button" class="btn btn-sm mb-1 btn-filter btn-outline-primary" data-target="Dealer">Dealer</button>
                                        <button type="button" class="btn btn-sm mb-1 btn-filter btn-outline-primary" data-target="Shop Owner">Shop Owner</button>
                                        <button type="button" class="btn btn-sm mb-1 btn-filter btn-outline-primary" data-target="Service Center">Service Center</button>
                                        <button type="button" class="btn btn-sm mb-1 btn-filter btn-outline-primary" data-target="Sales Representative">Sales Representative</button>
                                        <button type="button" class="btn btn-sm mb-1 btn-filter btn-outline-primary" data-target="Divisional Manager">Divisional Manager</button>
                                        <a href="<?php echo e(route('user.search')); ?>" class="btn btn-sm mb-1 btn-filter btn-outline-secondary">Reset</a>

                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-hover dataTable js-exportable table-custom spacing5">
                                <thead>
                                    <tr>
                                        <th><b>#</b></th>
                                        <th class="w60"><b> Name</b></th>
                                        <th><b>Role</b></th>
                                        <th><b>Division</b></th>
                                        <th><b>Cell No.</b></th>
                                        <th><b>Created Date</b></th>
                                        <th class="w100"><b> Action</b></th>
                                    </tr>
                                </thead>
                                <?php if( isset($users) ): ?>
                                    <?php if( count($users) > 0 ): ?>
                                        <tbody> 
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                                <tr data-status="<?php echo e($user->role ? $user->role->name : ''); ?>">
                                                    <td>
                                                        <img src="<?php echo e($user->media && $user->media->id != 0 ? $user->media->path : '//via.placeholder.com/50'); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo e($user->f_name ." ". $user->l_name); ?>" class="w35 h35 rounded">
                                                    </td>
                                                    <td>
                                                        <p class="mb-0"><b><?php echo e($user->name ?? 'Not Found'); ?></b></p>
                                                        <span><?php echo e($user->email ?? 'Not Found'); ?></span>
                                                    </td>
                                                    <td><span class="badge <?php echo e($user->role ? 'badge-info' : 'badge-danger'); ?>"><?php echo e($user->role->name ?? 'Not Defined'); ?></span></td>
                                                    <td><?php echo e($user->division ?? "Not Found"); ?></td>
                                                    <td><?php echo e($user->cell_no ?? 'Not Found'); ?></td>
                                                    <td><?php echo e($user->created_at ? $user->created_at->diffForHumans() : "Not Found"); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(route('users.edit',['user'=>$user->id])); ?>" type="button" class="btn btn-sm btn-default" title="Edit"><i class="fa fa-edit"></i></a>
                                                        
                                                    </td>
                                                </tr>                 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    <?php endif; ?>
                                <?php endif; ?>
                                
                                
                            </table>
                        </div>
                    </div>

                </div> 
            </div>
        </div>
    </div>






        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><b>Search User Credentials</b></h5>
                    </div>
                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <div class="alert alert-danger alert-dismissible" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                                <i class="fa fa-times-circle"></i> <?php echo e($error); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                    <div class="modal-body">
                        <?php echo Form::open(['method'=>'GET']); ?>

                            <div class="form-group">
                                <b><?php echo Form::label('division', 'Division');; ?></b>
                                <?php echo Form::select('division',\App\Models\User::divisions ?? [],null,['class'=>($errors->has('division')) ? 'form-control parsley-error' : 'form-control','placeholder'=>'Select Division']); ?> 
                            </div>
                            <div class="form-group">
                                <b><?php echo Form::label('district', 'District');; ?></b>
                                <?php echo Form::select('district', \App\Models\User::districts ?? [], null,['class'=>($errors->has('district')) ? 'form-control parsley-error' : 'form-control','placeholder'=>'Select District']); ?> 
                            </div>
                            <div class="form-group">
                                <b><?php echo Form::label('subdistrict', 'subdistrict');; ?></b>
                                <?php echo Form::select('subdistrict', App\Models\User::upazilas ?? [], null, ['class'=>($errors->has('subdistrict')) ? 'form-control parsley-error' : 'form-control','placeholder'=>'Select Subistrict']); ?> 
                            </div>
                    </div>
                    <div class="modal-footer">
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-round btn-default">Cancel</a>
                        <?php echo Form::submit('Search',['class'=>'btn btn-round btn-primary']); ?>

                        
                        <?php echo Form::close(); ?>

                    </div>
                    
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-footer-prepend'); ?>



<script src="<?php echo e(asset('html/assets/bundles/datatablescripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/dataTables.buttons.min.js')); ?>"></script> 
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/buttons.bootstrap4.min.js')); ?>"></script> 

<script src="<?php echo e(asset('js/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/buttons.colVis.min.js')); ?>"></script> 
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/buttons.html5.min.js')); ?>"></script> 
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/buttons.print.min.js')); ?>"></script> 


<script src="<?php echo e(asset('html/assets/js/pages/tables/table-filter.js')); ?>"></script>

    
    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom-footer-append'); ?>


    <script>

        ;$(document).ready(function(){
            
            // jquery Tables   
            $('.js-exportable').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    {
                        extend: 'collection',
                        text: 'Export',
                        buttons: [
                            'copy', 'csv', 'excel', 'pdf', 'print'
                        ],
                        //fade: true
                    }
                ]
            });

            <?php if( isset($usermodal) && $usermodal ==  true ): ?>
                $('#exampleModal').modal({
                    backdrop: 'static',
                });
            <?php endif; ?>
            

            
        });
        
    </script>
    
    
<?php $__env->stopSection(); ?>


    

<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\lubricant\resources\views/users/search-user.blade.php ENDPATH**/ ?>