

<?php $__env->startSection('title'); ?>
    All Users
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-header'); ?>   
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css')); ?>">
    
    
    <style>
        .light_version .card .body, .light_version .card .card-body {
            background: transparent!important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('block-header'); ?>
    <div class="block-header">

        <div class="row clearfix">
            <div class="col-md-6 col-sm-12">
                <h1>Users</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">PRHR</a></li>
                    <li class="breadcrumb-item active" aria-current="page">All Users</li>
                    </ol>
                </nav>
            </div>            
            
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="row clearfix">
        <div class="col-12">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <i class="fa fa-check-circle"></i> User created Sucessfully
                </div>
            <?php endif; ?>
            <?php if(session('delete')): ?>
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <i class="fa fa-times-circle"></i> User deleted Sucessfully
                </div>
            <?php endif; ?>
            <div class="card">
                <div class="header">All Users</div>
                <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary mb-3">Add User</a>
                <div class="body">
                    <div class="table-responsive">
                        <table class="table table-hover js-basic-example dataTable table-custom spacing5">
                            <thead>
                                <tr>
                                    <th><b>#</b></th>
                                    <th class="w60"><b> Name</b></th>
                                    <th><b>Role</b></th>
                                    
                                    <th><b>Cell No.</b></th>
                                    <th><b>Created Date</b></th>
                                    <th class="w100"><b> Action</b></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <img src="<?php echo e($user->media && $user->media->id != 0 ? $user->media->path : '//via.placeholder.com/50'); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo e($user->f_name ." ". $user->l_name); ?>" class="w35 h35 rounded">
                                        </td>
                                        <td>
                                            <p class="mb-0"><b><?php echo e($user->name ?? "Not found"); ?></b></p>
                                            <span><?php echo e($user->email ?? "Not Found"); ?></span>
                                        </td>
                                        <td><span class="badge <?php echo e($user->role ? 'badge-info' : 'badge-danger'); ?>"><?php echo e($user->role->name ?? 'Not Defined'); ?></span></td>
                                        
                                        <td><?php echo e($user->cell_no ?? "Not Found"); ?></td>
                                        <td><?php echo e($user->created_at ? $user->created_at->diffForHumans() : "Not found"); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('users.edit',['user'=>$user->id])); ?>" type="button" class="btn btn-sm btn-default" title="Edit"><i class="fa fa-edit"></i></a>
                                            
                                        </td>
                                    </tr>                            
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom-footer-append'); ?>
    <script src="<?php echo e(asset('html/assets/bundles/datatablescripts.bundle.js')); ?>"></script>
    
    
    
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-footer-prepend'); ?>
    
    <script src="<?php echo e(asset('html/assets/js/pages/tables/jquery-datatable.js')); ?>"></script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\lubricant\resources\views/users/all-users.blade.php ENDPATH**/ ?>