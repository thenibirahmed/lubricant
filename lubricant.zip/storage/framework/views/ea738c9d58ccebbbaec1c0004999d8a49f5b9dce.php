<?php $__env->startSection('title'); ?>
    Lubricant Dashboard
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('block-header'); ?>

    <div class="block-header">

        <div class="row clearfix">
            <div class="col-md-6 col-sm-12">
                <h1>Dashboard</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Lubricant</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                    </ol>
                </nav>
            </div>            
            
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

    
        
        <div class="row clearfix">
            <div class="col-6 col-md-4 col-xl-2">
                <div class="card">
                    <div class="body ribbon">
                        <div class="ribbon-box green">5</div>
                        <a href="" class="my_sort_cut text-muted">
                            <i class="icon-users"></i>
                            <span>Users</span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl-2">
                <div class="card">
                    <div class="body">
                        <a href="" class="my_sort_cut text-muted">
                            <i class="icon-like"></i>
                            <span>Dealers</span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl-2">
                <div class="card">
                    <div class="body ribbon">
                        <div class="ribbon-box orange">8</div>
                        <a href="" class="my_sort_cut text-muted">
                            <i class="icon-calendar"></i>
                            <span>Shop Owners</span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl-2">
                <div class="card">
                    <div class="body">
                        <a href="" class="my_sort_cut text-muted">
                            <i class="icon-credit-card"></i>
                            <span>Service Center</span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl-2">
                <div class="card">
                    <div class="body">
                        <a href="" class="my_sort_cut text-muted">
                            <i class="icon-calculator"></i>
                            <span>Divisional Manager</span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl-2">
                <div class="card">
                    <div class="body">
                        <a href="" class="my_sort_cut text-muted">
                            <i class="icon-pie-chart"></i>
                            <span>Sales Representative</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="row clearfix">
            
        </div>

        
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                
            </div>
        </div>

    



    
    
<?php $__env->stopSection(); ?>








<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\lubricant\resources\views/home.blade.php ENDPATH**/ ?>