
<div id="left-sidebar" class="sidebar">
    
    <div class="navbar-brand">
        <a href="<?php echo e(asset('/home')); ?>"><img src=" <?php echo e(asset('assets/images/icon.svg')); ?> " alt="Lubricant Logo" class="img-fluid logo"><span>Lubricant</span></a>
        <button type="button" class="btn-toggle-offcanvas btn btn-sm float-right"><i class="lnr lnr-menu icon-close"></i></button>
    </div>
    
    <div class="sidebar-scroll">
        
        <div class="user-account">
            <div class="user_div">
                <img width="100%" height="40px" src=" <?php echo e(Auth::user()->media ? Auth::user()->media->path : '//via.placeholder.com/50'); ?> " class="user-photo img img-responsive" alt="User Profile Picture">
            </div>
            <div class="dropdown">
                <span>Welcome,</span>
                <a href="javascript:void(0);" class="dropdown-toggle user-name" data-toggle="dropdown"><strong> <?php echo e(Auth::user()->name ?? 'Not Found'); ?> </strong></a>
                <ul class="dropdown-menu dropdown-menu-right account vivify flipInY">
                    <li><a href="#"><i class="icon-user"></i>My Profile</a></li>
                    <li><a href="app-inbox.html"><i class="icon-envelope-open"></i>Messages</a></li>
                    <li><a href="javascript:void(0);"><i class="icon-settings"></i>Settings</a></li>
                    
                    <li>
                        
                        <a class="icon-power" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                </ul>
            </div>                
        </div>  
        <nav id="left-sidebar-nav" class="sidebar-nav">
            <ul id="main-menu" class="metismenu">
                <li class="header">Main</li>
                
                <li class="open"><a href="<?php echo e(route('home')); ?>" class=""><i class="icon-speedometer"></i><span>Dashboard</span></a></li>
                <li class="header">Projects</li>
                <li><a href="#" class="has-arrow"><i class="icon-users"></i><span>Users</span></a>
                    <ul>
                        <li>
                            <?php if(Auth::user()->role && (Auth::user()->role->name == 'Admin' || Auth::user()->role->name == 'Super Admin') ): ?>
                            <a href="<?php echo e(route('users.index')); ?>">All Users</a>
                            <a href="<?php echo e(route('users.create')); ?>">Create Users</a>
                            <a href="<?php echo e(route('user.search')); ?>">Search Users</a>
                            <?php endif; ?>
                            <a href="<?php echo e(route('user.profile')); ?>">My Profile</a>
                        </li>
                    </ul>                 
                </li>
               
                
                            
            </ul>
        </nav>     
    </div>
</div>
<?php /**PATH E:\xampp\htdocs\lubricant\resources\views/dashboard/left-sidebar.blade.php ENDPATH**/ ?>