
<nav class="navbar top-navbar">
    <div class="container-fluid">

        
        <div class="navbar-left">
            <div class="navbar-btn">
                <a href="<?php echo e(asset('/home')); ?>"><img src="<?php echo e(asset('assets/images/icon.svg')); ?>" alt="Oculux Logo" class="img-fluid logo"></a>
                <button type="button" class="btn-toggle-offcanvas"><i class="lnr lnr-menu fa fa-bars"></i></button>
            </div>
            
        </div>


        
        <div class="navbar-right">
            <div id="navbar-menu">
                <ul class="nav navbar-nav">
                    
                    <li><a href="#" class="icon-menu"><i class="icon-power"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="progress-container"><div class="progress-bar" id="myBar"></div></div>
</nav>
<?php /**PATH E:\xampp\htdocs\lubricant\resources\views/dashboard/top-navbar.blade.php ENDPATH**/ ?>