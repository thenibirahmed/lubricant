

<?php $__env->startSection('title'); ?>
    User Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('block-header'); ?>
    <div class="block-header">

        <div class="row clearfix">
            <div class="col-md-6 col-sm-12">
                <h1>User</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">PRHR</a></li>
                    <li class="breadcrumb-item active" aria-current="page">User Profile</li>
                    </ol>
                </nav>
            </div>            
            
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>

<?php if(session('basic_update')): ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
        <i class="fa fa-check-circle"></i> Basic Data Changed Sucessfully
    </div>
<?php endif; ?>
<?php if(session('account_update')): ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
        <i class="fa fa-check-circle"></i> Account Data Changed Sucessfully
    </div>
<?php endif; ?>
<?php if(session('confirm_error')): ?>
    <div class="alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
        <i class="fa fa-times-circle"></i> Current Password is not correct
    </div>
<?php endif; ?>


<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
            <i class="fa fa-times-circle"></i> <?php echo e($error); ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<div class="row clearfix">
    <div class="col-md-12">
        <div class="card social">
            <div class="profile-header d-flex justify-content-between justify-content-center">
                <div class="d-flex">
                    <div class="mr-3">
                        <img src="../assets/images/user.png" class="rounded" alt="">
                    </div>
                    <div class="details">
                        <h5 class="mb-0"><?php echo e($user->name ?? ''); ?></h5>
                        <span class="text-light"><?php echo e($user->department ? $user->department->name : ''); ?></span>
                        
                    </div>                                
                </div>
                
            </div>
        </div>                    
    </div>

    <div class="col-xl-4 col-lg-4 col-md-5">
        <div class="card">
            <div class="header">
                <h2>Info</h2>
                <ul class="header-dropdown dropdown">                                
                    <li><a href="javascript:void(0);" class="full-screen"><i class="icon-frame"></i></a></li>
                    <li class="dropdown">
                        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"></a>
                        
                    </li>
                </ul>
            </div>
            <div class="body">
                <small class="text-muted">Role: </small>
                <p><?php echo e($user->role ? $user->role->name : "Not Found"); ?></p>
                <small class="text-muted">Email address: </small>
                <p><?php echo e($user->email ?? "Not Found"); ?></p>                            
                <hr>
                <small class="text-muted">Mobile: </small>
                <p><?php echo e($user->cell_no ?? "Not Found"); ?></p>
                <hr>
                <small class="text-muted">Shop Name: </small>
                <p class="m-b-0"><?php echo e($user->shop_name ?? 'Not Found'); ?></p>
                
            </div>
        </div>
    </div>

    <div class="col-xl-8 col-lg-8 col-md-7">
        <div class="card">
            <div class="header">
                <h2>Basic Information</h2>
                
            </div>
            <?php
                if (Auth::user()->role && ( Auth::user()->role->name != "Admin" && Auth::user()->role->name != "Super Admin" ) ){
                    $field = "disabled";
                }else{
                    $field = "";
                }
            ?> 
            

            <?php echo Form::open(['route'=>'user_basic_data.update','method'=>'PATCH']); ?>

            <div class="body">
                <div class="row clearfix">
                    <div class="col-lg-6 col-md-12">
                        <div class="form-group">                                                
                            <input <?php echo e($field); ?> type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>" placeholder="Name">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="form-group">                                                
                            <input <?php echo e($field); ?> type="text" name="fathers_name" class="form-control" value="<?php echo e($user->fathers_name); ?>" placeholder="Fathers Name">
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="form-group">
                            <select <?php echo e($field); ?> class="form-control" name="role_id">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($role == Auth::user()->role->name): ?>
                                        <option selected value="<?php echo e($key); ?>"><?php echo e($role); ?></option>
                                    <?php else: ?> 
                                        <option value="<?php echo e($key); ?>"><?php echo e($role); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="form-group">
                            <input <?php echo e($field); ?> type="text" name="shop_name" value="<?php echo e($user->shop_name ?? ''); ?>" class="form-control" placeholder="Shop Name">
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="form-group">
                            <input <?php echo e($field); ?> type="text" name="nid" class="form-control" value="<?php echo e($user->nid ?? "Not Found"); ?>" placeholder="National ID (NID)">
                        </div>
                    </div> 

                    <div class="col-lg-4 col-md-12">
                        <div class="form-group">
                            <input <?php echo e($field); ?> type="text" name="division" title="division" class="form-control" value="<?php echo e($user->division); ?>">
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="form-group">
                            <input <?php echo e($field); ?> type="text" name="district" title="district" class="form-control" value="<?php echo e($user->district); ?>">
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="form-group">
                            <input <?php echo e($field); ?> type="text" name="subdistrict" title="subdistrict" class="form-control" value="<?php echo e($user->subdistrict); ?>">
                        </div>
                    </div>

                    
                </div>
                <input type="submit" value="Update" class="btn btn-round btn-primary"> &nbsp;&nbsp;
                
            </div>
            <?php echo Form::close(); ?>

        </div>
        <div class="card">
            <div class="header">
                <h2>Account Data</h2>
            </div>
            <?php echo Form::open(['route'=>'user_account_data.update','method'=>'PATCH']); ?>

            <div class="body">
                <div class="row clearfix">
                    
                    <div class="col-lg-6 col-md-12">
                        <div class="form-group">
                            <input <?php echo e($field); ?> type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>" placeholder="Email">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="form-group">
                            <input <?php echo e($field); ?> type="text" name="cell_no" class="form-control" value="<?php echo e($user->cell_no); ?>" placeholder="Phone Number">
                        </div>
                    </div>                                
                    <div class="col-lg-12 col-md-12">
                        <hr>
                        <h6>Change Password</h6>
                        <div class="form-group">
                            <input type="password" name="current_password" class="form-control" placeholder="Current Password">
                        </div>
                        <div class="form-group">
                            <input type="password" name="password" class="form-control" placeholder="New Password">
                        </div>
                        <div class="form-group">
                            <input type="password" name="password_confirmation" class="form-control" placeholder="Confirm New Password">
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-round btn-primary">Update</button> &nbsp;&nbsp;
                <button type="button" class="btn btn-round btn-default">Cancel</button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom-footer-prepend'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\lubricant\resources\views/users/user-profile.blade.php ENDPATH**/ ?>