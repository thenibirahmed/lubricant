<!doctype html>
<html lang="en">

<head>
<title><?php echo $__env->yieldContent('title'); ?></title>
<meta charset="utf-8">

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">


<link rel="icon" href="favicon.ico" type="image/x-icon">
<!-- VENDOR CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/font-awesome/css/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/animate-css/vivify.min.css')); ?>">

<?php echo $__env->yieldContent('custom-header'); ?>
<!-- MAIN CSS -->
<link rel="stylesheet" href="<?php echo e(asset('html/assets/css/site.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

</head>
<body class="theme-green font-roboto light_version">

<!-- Page Loader -->
<div class="page-loader-wrapper">
    <div class="loader">
        <div class="bar1"></div>
        <div class="bar2"></div>
        <div class="bar3"></div>
        <div class="bar4"></div>
        <div class="bar5"></div>
    </div>
</div>

<!-- Theme Setting -->


<!-- Overlay For Sidebars -->
<div class="overlay"></div>

<div id="wrapper">

    
    <?php echo $__env->make('dashboard.top-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

    

    
    <?php echo $__env->make('dashboard.megamenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    

    <?php echo $__env->make('dashboard.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
    <div id="main-content">
        <div class="container-fluid">

            <?php echo $__env->yieldContent('block-header'); ?>
            

            <?php echo $__env->yieldContent('main-content'); ?>

        </div>
    </div>

    
</div>




<!-- Javascript -->
<script src="<?php echo e(asset('html/assets/bundles/libscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('html/assets/bundles/vendorscripts.bundle.js')); ?>"></script>







<?php echo $__env->yieldContent('custom-footer-prepend'); ?>
<script src="<?php echo e(asset('html/assets/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('html/assets/js/hrdashboard.js')); ?>"></script>
<!-- <script>
    /* To Disable Inspect Element */
    $(document).bind("contextmenu",function(e) {
        e.preventDefault();
    });
    
    $(document).keydown(function(e){
        if(e.which === 123){
           return false;
        }
    });
    
    document.onkeydown = function(e) {
        if(event.keyCode == 123) {
            return false;
        }
        if(e.ctrlKey && e.keyCode == 'E'.charCodeAt(0)){
            return false;
        }
        if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
            return false;
        }
        if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
            return false;
        }
        if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
            return false;
        }
        if(e.ctrlKey && e.keyCode == 'S'.charCodeAt(0)){
            return false;
        }
        if(e.ctrlKey && e.keyCode == 'H'.charCodeAt(0)){
            return false;
        }
        if(e.ctrlKey && e.keyCode == 'A'.charCodeAt(0)){
            return false;
        }
        if(e.ctrlKey && e.keyCode == 'F'.charCodeAt(0)){
            return false;
        }
        if(e.ctrlKey && e.keyCode == 'E'.charCodeAt(0)){
            return false;
        }
    }
</script> --> 
<?php echo $__env->yieldContent('custom-footer-append'); ?>
</body>
</html>
<?php /**PATH E:\xampp\htdocs\lubricant\resources\views/layouts/dash.blade.php ENDPATH**/ ?>