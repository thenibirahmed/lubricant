

<?php $__env->startSection('title'); ?>
    Create User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('block-header'); ?>
    <div class="block-header">

        <div class="row clearfix">
            <div class="col-md-6 col-sm-12">
                <h1>User</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">PRHR</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Create User</li>
                    </ol>
                </nav>
            </div>            
            
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="row clearfix">
        <div class="col-12">
            
            <?php if( $errors->any() ): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                        <i class="fa fa-times-circle"></i> <?php echo e($error); ?>

                    </div> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <div class="card">
                <div class="header"><h1>Create User</h1></div>
                <div class="body">
                    
                    <?php echo Form::open(['route'=>'users.store','files'=>true]); ?>

                    
						<div class="form-row">
							<div class="col">
                                <b><?php echo Form::label('name', 'Full Name');; ?></b>
                                <?php echo Form::text('name',old('name'),['class'=>($errors->has('name')) ? 'form-control parsley-error' : 'form-control','placeholder'=>'First Name']); ?>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
							</div>
							<div class="col">
                                <b><?php echo Form::label('fathers_name', 'Fathers Name');; ?></b>
                                <?php echo Form::text('fathers_name',old('fathers_name'),['class'=>($errors->has('fathers_name')) ? 'form-control parsley-error' : 'form-control','placeholder'=>'John Doe']); ?>

                                <?php $__errorArgs = ['fathers_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        
						<div class="form-row mt-4">
							
							<div class="col">
                                <b><?php echo Form::label('email', 'Email');; ?></b>
                                <?php echo Form::email('email',old('email'),['class'=>($errors->has('email')) ? 'form-control parsley-error' : 'form-control','placeholder'=>'email@example.com']); ?>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col">
                                <b><?php echo Form::label('nid', 'National ID');; ?></b>
                                <?php echo Form::text('nid',old('nid'),['class'=>($errors->has('nid')) ? 'form-control parsley-error' : 'form-control','placeholder'=>'National ID']); ?>                                  
                            </div>
                            <?php $__errorArgs = ['nid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            
						</div>

						

						
                        
                        <div class="form-row">
						    <div class="form-group col-md-4 col-6 mt-4">
                                <b><?php echo Form::label('role_id', 'Role');; ?></b>
                                <?php echo Form::select('role_id',['0'=>'Select Role'] + $roles ,null,['class'=>($errors->has('role_id')) ? 'form-control parsley-error' : 'form-control']); ?>

                                <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						    </div>
						    <div class="form-group col-md-4 col-6 mt-4">
                                <b><?php echo Form::label('cell_no', 'Cell No');; ?></b>
                                <?php echo Form::text('cell_no',null,['class'=>($errors->has('cell_no')) ? 'form-control parsley-error' : 'form-control']); ?>

                                <?php $__errorArgs = ['cell_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
						    </div>
						    <div class="form-group col-md-4 col-6 mt-4">
                                <b><?php echo Form::label('is_active', 'Is Active');; ?></b>
                                <?php echo Form::select('is_active',['0'=>'Not Active','1'=>'Active'],null,['class'=>'form-control']); ?>  
                            </div>
                        </div>
                        
                        
                        
                        
						<div class="form-row mt-2">
						    <div class="form-group col-md-4">
                                <b><?php echo Form::label('division', 'Division.');; ?></b>
                                <?php echo Form::select('division',\App\Models\User::divisions,old('division'),['class'=>($errors->has('division')) ? 'form-control parsley-error' :'form-control','data-region-id'=>'region']); ?>

                                <?php $__errorArgs = ['division'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						    </div>
						    <div class="form-group col-md-4">
                                <b><?php echo Form::label('district', 'District');; ?></b>
                                <?php echo Form::select('district',\App\Models\User::districts,old('district'),['class'=>($errors->has('district')) ? 'states form-control parsley-error' : 'states form-control']); ?>

                                <?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						    </div>
						    <div class="form-group col-md-4">
                                <b><?php echo Form::label('subdistrict', 'Subdistrict');; ?></b>
                                <?php echo Form::select('subdistrict',\App\Models\User::upazilas,old('subdistrict'),['class'=>($errors->has('subdistrict')) ? 'states form-control parsley-error' : 'states form-control']); ?>

                                <?php $__errorArgs = ['subdistrict'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						    </div>
                        </div>
                        <p class="text-info">These address credentials cannot be changed.</p>

                        <div class="form-row">
						    <div class="form-group col-md-4 col-6">
                                <b><?php echo Form::label('shop_name', 'Shop Name');; ?></b>
                                <?php echo Form::text('shop_name', null, ['class'=>($errors->has('shop_name')) ? 'form-control parsley-error' : 'form-control']); ?>

                                <?php $__errorArgs = ['shop_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						    </div>
						    <div class="form-group col-md-4 col-6">
                                <b><?php echo Form::label('trade_lisence', 'Trade Lisence');; ?></b>
                                <?php echo Form::file('trade_lisence',['id'=>'file-1','class'=>($errors->has('trade_lisence')) ? 'form-control form-control-file parsley-error' : 'form-control form-control-file']); ?>

                                <?php $__errorArgs = ['trade_lisence'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
						    </div>
						    <div class="form-group col-md-4 col-6">
                                <b><?php echo Form::label('shop_image', 'Shop Image');; ?></b>
                                <?php echo Form::file('shop_image',['id'=>'file-2','class'=>'form-control form-control-file']); ?>  
                            </div>
                        </div>
                        <p class="text-info">These fields are optional fields if the role "Shop owner" or "Service Center"</p>

						<div class="form-row mt-3">
							<div class="col">
                                <b><?php echo Form::label('password', 'Password');; ?></b></b>
                                <?php echo Form::password('password',['class'=>($errors->has('password')) ? 'form-control parsley-error' : 'form-control','placeholder'=>'Password']); ?>  
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
							<div class="col">
								<b><?php echo Form::label('password_confirmation', 'Confirm Password');; ?></b></b>
                                <?php echo Form::password('password_confirmation',['class'=>'form-control','placeholder'=>'Confirm Password']); ?>  
							</div>
                        </div>


                        

                        <div class="form-row mt-4">
                            <div class="col-6">
                                <?php echo Form::submit('Create User',['class'=>'btn btn-primary']); ?>

                            </div>
                            <div class="col-6 text-right">
                                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">Go Back</a>
                            </div>
                        </div>
						

					<?php echo Form::close(); ?>


                </div>  
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom-footer-prepend'); ?>
    <script src="<?php echo e(asset("js/crs.min.js")); ?>"></script>
    <script>
        $(document).ready(function(){
			$('input#img_id').change(function(){

				if (this.files && this.files[0]) {
			        var reader = new FileReader();
			        reader.onload = function (e) {
			            $('#pr').attr('src',e.target.result);
			        };
			        reader.readAsDataURL(this.files[0]);
			    }

			});
		});
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\lubricant\resources\views/users/create-users.blade.php ENDPATH**/ ?>